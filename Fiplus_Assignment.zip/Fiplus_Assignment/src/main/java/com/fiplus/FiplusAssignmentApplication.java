package com.fiplus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiplusAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(FiplusAssignmentApplication.class, args);
	}

}
