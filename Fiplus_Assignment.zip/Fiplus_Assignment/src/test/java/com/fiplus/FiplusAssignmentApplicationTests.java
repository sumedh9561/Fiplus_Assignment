package com.fiplus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiplusAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
